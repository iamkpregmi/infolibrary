<?php
	include("config.php");
	$id = $_GET['userid'];
	$sel = mysqli_query($link,"SELECT * FROM `infolibrary` WHERE id = '$id'");
	$arr = mysqli_fetch_assoc($sel);
	extract($_POST);
	if(isset($sub))
	{
		$sel = mysqli_query($link,"UPDATE `infolibrary` SET `title` = '$title', `content` = '$content' WHERE `infolibrary`.`id` = '$id'");	
		header("location: index.php");
	}
	if(isset($del))
	{ 
		$sel = mysqli_query($link,"DELETE FROM `infolibrary` WHERE `id` = '$id'");	
		header("location: index.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Updateinfo</title>
		<style type="text/css">
			#container {
				position: fixed;
				width: 100%;
				top: 0px;
				left: 0px;
			    overflow: hidden;
			    background-color: #333;
			    font-family: Arial;
			}

			#container a {
			    float: left;
			    font-size: 16px;
			    color: white;
			    text-align: center;
			    padding: 14px 16px;
			    text-decoration: none;
			}
			#container a:hover {
			    background-color: red;
			}
			#content{
				position: absolute;
				width: 100%;
				top: 70px;
			}
			#title
			{
				width: 70%;
			}
		</style>
	</head>
	<body>
		<div id="container">
		  <a href="index.php">Home</a>
		  <a href="about.php">About</a>
		  <a href="addinfo.php">Add Info</a> 
		</div>
		<div id="content">
		<form method="post" autocomplete="off">
			<label>Title of the topic</label>
			<br/>
			<input id ="title" type="text" name="title" value ="<?=$arr['title'] ?>" required/>
			<br/>
			<label>Contents</label>
			<br/>
			<textarea cols="130" rows="25" name="content" required><?=$arr['content'] ?></textarea>
			<br/>
			<input type="submit" name="sub" value="Update"/>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" name="del" value="Delete"/>			
		</form>
		</div>
	</body>
</html>