<?php
	$link = mysqli_connect("localhost","root","","krishna") or die("Connect error :(");
?>