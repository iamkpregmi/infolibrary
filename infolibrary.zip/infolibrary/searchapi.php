<?php
	include("config.php");
	if(!empty($_GET['search']))
	{
		$usersearch = trim($_GET['search']);
		
		if(!empty($usersearch))
		{
			$sel = mysqli_query($link,"select * from infolibrary where content like '%$usersearch%'");
			$row = mysqli_num_rows($sel);
			if($row!==0)
			{
				while($arr = mysqli_fetch_assoc($sel))
				{
					$id = $arr['id'];
					echo "<fieldset>";
					echo "<label style='color: blue; font-size: 25px;'>".$arr['title']."</label>";
					echo " <a href='update.php?userid=$id'>Edit</a>";
					echo "<hr/>".$arr['content'];
					echo "</fieldset><br/>";
				}
			}
			else
			{
				echo "<label style='color: red; font-size: 35px;'>Result not found :( </label>";
			}
		}
	}
?>