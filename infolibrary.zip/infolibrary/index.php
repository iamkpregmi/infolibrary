<!DOCTYPE html>
<html lang="en-us">
	<head>
		<title>info Library</title>
		<script src="js/jquery-3.3.1.min.js"></script>
		<script>
			$(document).ready(function()
			{
				$('#userinput').keyup(function()
				{
					var s = $(this).val();
					
					$.get('searchapi.php',{search:s},function(res)
					{
						$('#res').html(res);

					});
				})
			})
		</script>
		<style type="text/css">
			input[type=text], select {
			    width: 75%;
			    padding: 12px 20px;
			    margin: 8px 0;
			    display: inline-block;
			    border: 1px solid #ccc;
			    border-radius: 4px;
			    box-sizing: border-box;
			    padding: 12px 20px 12px 40px;
			}
			#container {
				position: fixed;
				width: 100%;
				top: 0px;
				left: 0px;
			    overflow: hidden;
			    background-color: #333;
			    font-family: Arial;
			}

			#container a {
			    float: left;
			    font-size: 16px;
			    color: white;
			    text-align: center;
			    padding: 14px 16px;
			    text-decoration: none;
			}
			#container a:hover {
			    background-color: red;
			}
			#show {
			    display: block;
			}
			#info{
				color: #000;
				font-size: 40px;
			}
			#library{
				color: #000;
				font-size: 55px;
				text-decoration: underline;
				font-weight: bold;
			}
		</style>
	</head>
	<body>
		<h1 id="Home"></h1>
		<a href="#Home">
			<button type="button" style="position: fixed; bottom: 10px; right: 10px; z-index: 999;">^TOP^</button>
		 </a>
		<div id="container">
		  <a href="index.php">Home</a>
		  <a href="addinfo.php">Add Info</a>
		  <a href="about.php">About</a>
		</div>
		<center>
		<br/><br/><br/>
			<form action="" method="get" autocomplete="off"> 
				<label id="info">info</label>
				<label id="library">LIBRARY</label>
					<br><br>
				<div>
				<input type="text" border="3" name="userinput" id="userinput" maxlength="255" title="Type here to Search" placeholder="Type here to search"/>
				</div>
			</form>
		</center>
		<label id="res"></label>
	</body>
</html>