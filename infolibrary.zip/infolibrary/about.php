<!DOCTYPE html>
<html>
	<head>
		<title>About</title>
		<style type="text/css">
			#container {
				position: fixed;
				width: 100%;
				top: 0px;
				left: 0px;
			    overflow: hidden;
			    background-color: #333;
			    font-family: Arial;
			}

			#container a {
			    float: left;
			    font-size: 16px;
			    color: white;
			    text-align: center;
			    padding: 14px 16px;
			    text-decoration: none;
			}
			#container a:hover {
			    background-color: red;
			}
			#content{
				position: absolute;
				width: 100%;
				top: 160px;
			}
			img{
				width: 200px;
				height: 200px;
				border-radius: 50%;
			}
		</style>
	</head>
	<body>
		<div id="container">
		  <a href="index.php">Home</a>
		  <a href="addinfo.php">Add Info</a>
		  <a href="about.php">About</a> 
		</div>
		<div id="content">
			<center>
				<img src="images/developer.jpg">
				<br/><br/>
				<h3>Design and Develop by: Krishna Prasad Regmi &copy;</h3>
			</center>
		</div>
	</body>
</html>