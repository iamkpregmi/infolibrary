<?php
	include("config.php");
	extract($_POST);
	if(isset($sub))
	{
		$id = rand(0000,9999999999);
		if(mysqli_query($link,"insert into infolibrary values('$id','$title','$content')"))
			header("location: index.php");
		else
			echo "Oops something Wrong Try again...";
	}
		
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Addinfo</title>
		<style type="text/css">
			#container {
				position: fixed;
				width: 100%;
				top: 0px;
				left: 0px;
			    overflow: hidden;
			    background-color: #333;
			    font-family: Arial;
			}

			#container a {
			    float: left;
			    font-size: 16px;
			    color: white;
			    text-align: center;
			    padding: 14px 16px;
			    text-decoration: none;
			}
			#container a:hover {
			    background-color: red;
			}
			form{
				position: absolute;
				width: 100%;
				top: 70px;
			}
			#title
			{
				width: 70%;
			}
		</style>
	</head>
	<body>
		<div id="container">
		  <a href="index.php">Home</a>
		  <a href="addinfo.php">Add Info</a>
		  <a href="about.php">About</a> 
		</div>
		<form method="post" autocomplete="off">
			<label>Title of the topic</label>
			<br/>
			<input id="title" type="text" name="title" required/>
			<br/>
			<label>Contents</label>
			<br/>
			<textarea cols="130" rows="25" name="content" required></textarea>
			<br/>
			<input type="submit" name="sub" value="Submit"/>			
		</form>
	</body>
</html>